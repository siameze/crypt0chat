<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:500px;
}

</style>

<?php

echo "<title>";
echo "-SyN's- Mod Installation Page</title>";

echo "<div id=PageTitle align=center><br/>";
echo "<hr><h1>-SyN's- Mod Installation Page</h1>";
echo "<hr><br/>";

echo "<h3>Modifications to be installed:</h3>";

echo "<table border=1 width=100% align=center style=border-spacing:.65em;>";
echo "<th>Name of Mod</th><th>Version</th><th>Ready Status</th>";

$file1 = "admin_install.php";

if (file_exists($file1)){

echo "<tr><td align=center><font color=green><b>SyN's Administration Script Plus Extras</b></font>";
echo "</td><td align=center><b>1 beta v1.0</b>";
echo "</td><td align=center><b><a href=./".$file1.">Click Here</a> to begin installation.</b></td></tr>";

}else{

echo "<tr><td align=center><font color=red><b>None avaliable</b></font>";
echo "</td><td align=center><b>N/A</b>";
echo "</td><td align=center><b>There are no mods to install....</b></td></tr>";
}
echo "</table><div>";
?>