<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:500px;
}

</style>

<?php

echo "<title>SyN's Administration Script Installation</title>";

echo "<div id=PageTitle><br/>";
echo "<hr><h1><center>Admin Installation In Progress</center></h1>";
echo "<hr><br/>";

require('../lib/config.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']); 

///////////////////////////////////////////////////////////////////
//Creates a Database table if it don't exist
///////////////////////////////////////////////////////////////////

$table1 = "ajax_chat_registered_members";
$table2 = "ajax_chat_channels";

if(mysql_num_rows(mysql_query("SHOW TABLES LIKE '".$table1."'"))==1) {

echo "&nbsp;&nbsp;-&nbsp;The table named <b>".$table1."</b> exists in your chats database.<br>&nbsp;&nbsp;-&nbsp;Skipping to the next table...<br/><br/>";

}else{ 

mysql_query("CREATE TABLE IF NOT EXISTS `ajax_chat_registered_members` (
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ROLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME_2` (`NAME`),
  FULLTEXT KEY `NAME` (`NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1");

echo "&nbsp;&nbsp;-&nbsp;The table named <b>".$table1."</b> was successfully added to your chats database.<br>&nbsp;&nbsp;-&nbsp;Continuing Installation...<br/><br/>";
}

if(mysql_num_rows(mysql_query("SHOW TABLES LIKE '".$table2."'"))==1) {

echo "&nbsp;&nbsp;-&nbsp;The table named <b>".$table2."</b> exists in your chats database.<br>&nbsp;&nbsp;-&nbsp;Procceding with installation..<br/><br/>";

}else{ 

mysql_query("CREATE TABLE IF NOT EXISTS `ajax_chat_channels` (
  `chan_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chan_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`chan_ID`),
  UNIQUE KEY `NAME_2` (`chan_NAME`),
  FULLTEXT KEY `NAME` (`chan_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1");

echo "&nbsp;&nbsp;-&nbsp;The table named <b>".$table2."</b> was successfully added to your chats database<br>&nbsp;&nbsp;-&nbsp;Continuing Installation...<br/><br/>";

mysql_query("INSERT INTO `ajax_chat_channels` (chan_NAME) VALUES ('CHANNEL_1'),('CHANNEL_2'),('CHANNEL_3'),('CHANNEL_4'),('CHANNEL_5'),('CHANNEL_6'),('CHANNEL_7'),('CHANNEL_8'),('CHANNEL_9')") or die(mysql_error());

}

$table_check = mysql_query("SELECT PASS2 FROM `ajax_chat_registered_members`");

if($table_check == 0){ 
echo "&nbsp;&nbsp;-&nbsp;So far  so good!<br/><br/>";
} else {
mysql_query("ALTER TABLE `ajax_chat_registered_members` DROP column PASS2") or die(mysql_error()); 
echo "&nbsp;&nbsp;-&nbsp;Cleaning up old Database Information<br/><br/>";
}

$filename = "../reg-success.php";

if (file_exists($filename))  {

mysql_query("ALTER TABLE ajax_chat_registered_members
ADD column CHANNELS varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL1 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL2 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL3 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL4 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL5 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL6 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL7 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL8 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column CHANNEL9 varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column BANNED_BY varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column BAN_REASON varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column WEBSITE varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column YOUTUBE varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column FACEBOOK varchar(255) COLLATE utf8_unicode_ci NOT NULL,
ADD column ABOUTME varchar(255) COLLATE utf8_unicode_ci NOT NULL") or die(mysql_error());


    echo "&nbsp;&nbsp;-&nbsp;You are <b><u>NOT</u></b> using <b>SyN's Registration Mod</b> or you havent updated to the <b><u>latest version</u></b>.<br/><br/>&nbsp;&nbsp;-&nbsp;Don't worry....<br/>&nbsp;&nbsp;-&nbsp;I will update it for you......Relax now and wipe the sweat from your forehead.<br/><br/>";

}


echo "<br/>&nbsp;&nbsp;-&nbsp;Installation is complete!</br/><i>&nbsp;&nbsp;*&nbsp;Make sure you check the instructions folder in the zip package for the file edits.</i><br/>&nbsp;&nbsp;-&nbsp;Click <a href=../admin/>Here</a> to go to your admin dashboard.";

echo "</div>";
?>