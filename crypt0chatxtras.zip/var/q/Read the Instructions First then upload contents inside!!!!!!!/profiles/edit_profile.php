<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:600px;
}

.userPIC{
position:absolute;
margin-left:80px;
}

.userINFO{
position:relative;
margin-left:auto;
margin-right:auto;
margin-top:-35px;
}

</style>

<?php

session_start();

$now = time();

if(!$_SESSION['yourname']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the Profile Login Page!</h1></center>";
header("refresh:2;url=./login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the Profile Login Page!</h1></center>"; 
        header("refresh:5;url=./login.php");

    }else{

$user = $_SESSION['yourname'];

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$query = $user;
$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME like '%".$query."%'";
$num_rows = mysql_num_rows(mysql_query($sql));

$result = mysql_query($sql);
$row = mysql_fetch_array($result);

$id = $row['ID'];


echo "<title>Editing ".$user."'s Profile</title>";

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>Editing ".$user."'s Profile</h1>";
echo "<hr><br/>";


echo "<form action=update.php?user=".$user."&id=".$id." method=post><br/>";
echo "<table class=userINFO>";
echo "<tr><td>Website:</td><td><input type=text name=website size=60px></td></tr>";
echo "<tr><td>YouTube:</td><td><input type=text name=youtube size=60px></td></tr>";
echo "<tr><td>Facebook:</td><td><input type=text name=facebook size=60px></td></tr>";
echo "</table>";

echo "<hr>";
echo "<h3>About Me:</h3><h4>(Plain text only! No HTML)</h4></br>";

echo "<textarea name=about_me style=width:450px;height:150px;></textarea><br/>";
echo "<input type=submit value=Update>";
echo "</form>";

}
?>
