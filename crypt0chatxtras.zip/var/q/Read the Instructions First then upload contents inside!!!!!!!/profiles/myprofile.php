<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<script>

$(document).ready(function()
    {
        $('input:submit').attr("disabled", true);
        var textCounter = false;
        $('input:text, textarea').keyup(check_submit);
        $('select').change(check_submit);
        
        function check_submit() {
            $('input:text, textarea, select').each(function()
              {
                if ($(this).val().length == 0) {
                    textCounter = true;
                    return false;
                   }
                else {
                    textCounter = false;
                }
             });
            
            $('input:submit').attr("disabled", textCounter);
        }
    });


</script>

<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:775px;
}

.userPIC{
position:relative;
margin-left:auto;
margin-right:auto;
}

.userINFO{
position:relative;
margin-left:auto;
margin-right:auto;
margin-top:30px;
}

.AboutMe{
position:relative;
margin-top:7px;
}

</style>

</style>

<?php

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$query = mysql_real_escape_string($_GET['user']);
$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME like '%".$query."%'";
$num_rows = mysql_num_rows(mysql_query($sql));

if($query == ""){
echo "<title>ERROR!</title>";
echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>Nothing here for you to see.<br/>Please Leave Now!</h1>";
echo "<hr></div>";

}else if(mysql_num_rows(mysql_query($sql)) == 0){
echo "<title>User Is Not Registered!!!</title>";
echo "<div id=PageTitle align=center><br><hr>";
echo "<h1>This user is not a member of this chatroom.</h1><h3>If you are ".$query." then please register with the chat below.</h3>";
echo "<hr>";

echo "<form action=../reg-results.php method=post enctype=multipart/form-data  OnSubmit=return ConfirmForm()>";
echo "<table><br><br><strong>Fill out the form.</strong><br><br>";
echo "<tr><td>Username:</td><td> <input type=text name=chatUSER></td></tr>";
echo "<tr><td>Password: </td><td><input type=password name=chatPASS></td></tr>";
echo "<tr><td>Confirm Password: </td><td><input type=password name=chatPASS2></td></tr>";
echo "<tr><td>";
echo "<tr><td></td><td><input align=center type=submit id=submit name=submit value=Register disabled=disabled /></td></tr></table>";
echo "</form></div>";

}else{

$result = mysql_query($sql);
$row = mysql_fetch_array($result);

echo "<title>";
echo $query;
echo "'s Profile Page!</title>";

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>".$query."'s Profile Page</h1>";
echo "<hr><br/>";

echo "<table border=1 class=userPIC>";
echo "<tr><td><img src=../img/avatars/";
echo $query;
echo ".png onerror=this.src='../img/avatars/guest.png'; width=150 height=150 />";
echo "</td></tr></table><br/>";
echo "<hr>";
echo "<table border=0 class=userINFO>";
echo "<tr><td>";
echo "<b>Name:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;".$query;
echo "</td></tr>";

if($row['ROLE'] == ""){
echo "<tr><td><b>Role:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;AJAX_CHAT_GUEST</td></tr>";
}else{
echo "<tr><td><b>Role:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;".$row['ROLE']."</td></tr>";
}

if($row['WEBSITE'] == ""){
echo "<tr><td><b>Website:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;N/A</td></tr>";
}else{
echo "<tr><td><b>Website:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$row['WEBSITE']."><b>".$row['WEBSITE']."</b></a></td></tr>";
}

if($row['YOUTUBE'] == ""){
echo "<tr><td><b>YouTube:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;N/A</td></tr>";
}else{
echo "<tr><td><b>YouTube:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$row['YOUTUBE']."><b>".$row['YOUTUBE']."</b></a></td></tr>";
}

if($row['FACEBOOK'] == ""){
echo "<tr><td><b>Facebook:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;N/A</td></tr>";
}else{
echo "<tr><td><b>Facebook:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$row['FACEBOOK']."><b>".$row['FACEBOOK']."</b></a></td></tr>";
}

echo "</table>";

echo "<div class=aboutME><br><hr>";
echo "<h3>About Me:</h3>";

echo "<table width=450 height=150 border=1><tr><td>";
if($row['ABOUTME'] == ""){
echo "<center>In a few words or less, share some info about yourself here.</center>";
}else{
echo "<center>".$row['ABOUTME']."</center>";
echo "<br/>";
}
echo "</table></div>";

echo "<div>";


}
?>

<script language="JavaScript">

function ConfirmForm()

{

      return confirm("  Make sure all is correct." + 

                   "  Click OK to continue your submission or Cancel to abort.  ");

}

</script>