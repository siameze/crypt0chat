<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:775px;
}

</style>

<?php


session_start();

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$id = mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['id'])))));
$user = mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['user'])))));
$website= mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['website'])))));
$youtube = mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['youtube'])))));
$facebook = mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['facebook'])))));
$aboutme = mysql_real_escape_string(nl2br(htmlentities(strip_tags(trim($_SESSION['about_me'])))));

mysql_query("UPDATE ajax_chat_registered_members SET WEBSITE='$website', YOUTUBE='$youtube', FACEBOOK='$facebook', ABOUTME='$aboutme' WHERE id='$id'");

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>".$user."'s Profile was Saved!</h1>";
echo "<hr><br/>";
echo "<h3>Returning you to your profile page!</h3>";

        header("refresh:3;url=./myprofile.php?user=$user");


        session_destroy();

?>
<? ob_flush(); ?>