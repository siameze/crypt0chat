<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:775px;
}

.userPIC{
position:relative;
margin-left:auto;
margin-right:auto;
}

.userINFO{
position:relative;
margin-left:auto;
margin-right:auto;
margin-top:30px;
}

.AboutMe{
position:relative;
margin-top:7px;
}

</style>

<?php

session_start();

$now = time();

if(!$_SESSION['yourname']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the Profile Login Page!</h1></center>";
header("refresh:2;url=./login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the Profile Login Page!</h1></center>"; 
        header("refresh:5;url=./login.php");

    }else{ 

$_SESSION['id'] = $_GET['id'];
$_SESSION['user'] = $_GET['user'];

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$query = $_SESSION['user'];
$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME like '%".$query."%'";
$num_rows = mysql_num_rows(mysql_query($sql));

echo "<title>".$_SESSION['user']."'s Profile Preview</title>";

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>".$_SESSION['user']."'s Profile Preview</h1>";
echo "<hr><br/>";

$result = mysql_query($sql);
$row = mysql_fetch_array($result);

echo "<table border=1 class=userPIC>";
echo "<tr><td><img src=../img/avatars/";
echo $query;
echo ".png onerror=this.src='../img/avatars/guest.png'; width=150 height=150 />";
echo "</td></tr></table><br/>";
echo "<hr>";
echo "<table border=0 class=userINFO>";
echo "<tr><td>";
echo "<b>Name:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;".$query;
echo "</td></tr>";

echo "<tr><td><b>Role:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;".$row['ROLE']."</td></tr>";

//Preview Variables:

$_SESSION['website'] = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['website']))));
$_SESSION['youtube'] = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['youtube']))));
$_SESSION['facebook'] = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['facebook']))));
$_SESSION['about_me'] = nl2br(htmlentities(strip_tags(trim($_POST['about_me']))));

if($_SESSION['website'] == ""){
echo "<tr><td><b>Website:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<b>No info Provided!</b></td></tr>";
}else{
echo "<tr><td><b>Website:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$_SESSION['website']."><b>".$_SESSION['website']."</b></a></td></tr>";
}

if($_SESSION['youtube'] == ""){
echo "<tr><td><b>YouTube:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<b>No info Provided!</b></td></tr>";
}else{
echo "<tr><td><b>YouTube:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$_SESSION['youtube']."><b>".$_SESSION['youtube']."</b></a></td></tr>";
}

if($_SESSION['facebook'] == ""){
echo "<tr><td><b>Facebook:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<b>No info Provided!</b></td></tr>";
}else{
echo "<tr><td><b>Facebook:</b></td><td size:60px>&nbsp;&nbsp;&nbsp;<a href=".$_SESSION['facebook']."><b>".$_SESSION['facebook']."</b></a></td></tr>";
}

echo "</table>";

echo "<div class=aboutME><br><hr>";
echo "<h3>About Me:</h3>";

echo "<table width=450 height=150 border=1><tr><td>";
if($_SESSION['about_me'] == ""){
echo "<center>No info Provided!</center>";
}else{
echo "<center>".$_SESSION['about_me']."</center>";
}
echo "<br/>";
echo "</table></div>";

echo "<br/><b><a href=./profile_saved.php?id=".$_SESSION['id']."&user=".$_SESSION['user'].">Save?</a>";

echo "&nbsp;&nbsp;&nbsp;";

echo "<a href=./edit_profile.php?id=".$_SESSION['id']."&user=".$_SESSION['user'].">Edit Again?</a></b>";
echo "<div>";
}
?>
<? ob_flush(); ?>