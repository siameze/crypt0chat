<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:600px;
}

</style>

<?php 

session_start();
session_destroy();

echo "<title>Profile Login</title>";

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>Login to edit your Profile</h1>";
echo "<hr><br/>";

echo "<div class=login align=center>";
echo "<table><tr>";
echo "<form method=post action=pro_login_results.php>";
echo "<tr><td>Username: </td><td><input name=yourname type=text /></td></tr>";
echo "<tr><td>Password: </td><td><input name=yourpass type=password /></td></tr>";
echo "<tr><td></td><td><input type=submit name=Submit value=Login /></td>";
echo "</form></tr></table></div></div>";


?>
<? ob_flush(); ?>