<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
background:#000000;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#PageTitle{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:600px;
}

</style>
<?php

session_start();

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$name = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['yourname']))));
$pass = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['yourpass']))));

$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME='$name' AND PASS='$pass' AND ROLE !='AJAX_CHAT_BANNED'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);

////////////////////////////////////////////////////////////
//Check to see if the variables matches a row of users info
////////////////////////////////////////////////////////////

if($count==1){
$_SESSION['yourname'] = $name;
$_SESSION['yourpass'] = $pass;
$_SESSION['start'] = time(); 
$_SESSION['expire'] = $_SESSION['start'] + (20 * 40);

echo "<title>Profile Login</title>";

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>Login was Successful!</h1>";
echo "<hr><br/></div>";
header("refresh:3;url=./edit_profile.php?user=$name");

}else{

echo "<div id=PageTitle align=center><br/><hr>";
echo "<h1>Login Failed!</h1>";
echo "<hr><br/></div>";
header("refresh:3;url=./login.php");

}

?>
<? ob_flush(); ?>