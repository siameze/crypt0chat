<title>Chatroom Registration Form</title>
<script type="text/javascript"  src="http://code.jquery.com/jquery.min.js"></script>

<script>

$(document).ready(function()
    {
        $('input:submit').attr("disabled", true);
        var textCounter = false;
        $('input:text, textarea').keyup(check_submit);
        $('select').change(check_submit);
        
        function check_submit() {
            $('input:text, textarea, select').each(function()
              {
                if ($(this).val().length == 0) {
                    textCounter = true;
                    return false;
                   }
                else {
                    textCounter = false;
                }
             });
            
            $('input:submit').attr("disabled", textCounter);
        }
    });


</script>

<style type="text/css">

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

body{
background:#686868; 
font-family:Arial,Helvetica,sans-serif;
}

</style>

<body>
<form action="reg-results.php" method="post" enctype="multipart/form-data"  OnSubmit="return ConfirmForm();">
<table><br><br><strong>Fill out the form.</strong><br><br>
<tr><td>Username:</td><td> <input type="text" name="chatUSER"></td></tr>
<tr><td>Password: </td><td><input type="password" name="chatPASS"></td></tr>
<tr><td>Confirm Password: </td><td><input type="password" name="chatPASS2"></td></tr>
<tr><td>
<tr><td></td><td><input align="center" type="submit" id="submit" name="submit" value="Register" disabled="disabled" /></td></tr></table>
</form>
</body>
<script language="JavaScript">

function ConfirmForm()

{

      return confirm("  Make sure all is correct." + 

                   "  Click OK to continue your submission or Cancel to abort.  ");

}

</script>