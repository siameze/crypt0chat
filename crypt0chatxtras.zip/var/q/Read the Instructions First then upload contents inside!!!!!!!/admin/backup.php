<?php
//////////////////////////////////////////////
//Get Required info for database connection
//////////////////////////////////////////////
require('../lib/config.php');

$host = $config['dbConnection']['host'];
$user = $config['dbConnection']['user'];
$pass = $config['dbConnection']['pass'];
$name = $config['dbConnection']['name'];

$link = mysql_connect($host, $user, $pass);

///////////////////////////////////////////
//Retrieve your chat database and creates a 
//backup file in the server
///////////////////////////////////////////
$db_list = mysql_list_dbs($link);

while ($row = mysql_fetch_object($db_list)) {
    $name = $row->Database;

    $backupfile = $name.'_'.date("m_d_Y").'.sql';

    system("mysqldump -h $host -u $user -p$pass $name > $backupfile");

}

//////////////////////////////////////////////
//Checks to see if the File was created
//and not corrupted and is ready for download
//////////////////////////////////////////////
if(file_exists($backupfile)){

header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($backupfile));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($backupfile));
    ob_clean();
    flush();
  if (readfile($backupfile)) 
  {

/////////////////////////////////////////////////
//Deletes file from the server after downloaded
/////////////////////////////////////////////////
    unlink($backupfile);
    unlink('information_schema_'.date("m_d_Y").'.sql');
  }
    exit;
}
?>