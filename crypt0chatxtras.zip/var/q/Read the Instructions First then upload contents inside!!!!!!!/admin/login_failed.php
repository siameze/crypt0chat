<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>

<?php 
session_start();

echo "<center><h1>Invalid Login!</h1></center>";

session_destroy();

header("refresh:2;url=./login.php");
?>
<? ob_flush(); ?>