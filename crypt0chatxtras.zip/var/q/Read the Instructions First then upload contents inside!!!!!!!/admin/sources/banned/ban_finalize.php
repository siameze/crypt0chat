<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>

<?php

require('../../../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$id = $_GET['id'];
$user = $_GET['name'];
$banned_by = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['admin']))));

mysql_query("UPDATE ajax_chat_registered_members SET BANNED_BY='$banned_by' WHERE id='$id'");

echo "<center><h1>".$user."'s Ban information was fully updated!</h1><h3>Redirecting you back to the Banned User List Dashboard...</h3></center>";

header("refresh:3;url=./dashboard.php");

?>
<? ob_flush(); ?>