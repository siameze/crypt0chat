<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#BanUpdate{
position:relative;
margin-top:50px;
}

</style>


<?php

require('../../../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$id = $_GET['id'];
$user = $_GET['name'];
$ban_reason = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['Ban_Reason']))));

mysql_query("UPDATE ajax_chat_registered_members SET BAN_REASON='$ban_reason' WHERE id='$id'");

echo "<div id=BanUpdate>";
echo "<hr>";
echo "<center><h1>".$user."'s reason for being banned was recorded!</h1><h3>Please specify the Administrator who is responsible for banning ".$user."</center>";
echo "<hr>";

echo "<table style=border-spacing:1em; border=1 align=center><th>Select Below</th>";
echo "<form action=ban_finalize.php?name=".$user."&id=".$id." method=post>";

$chat_admin = "AJAX_CHAT_ADMIN";

$data = mysql_query("SELECT * FROM ajax_chat_registered_members WHERE ROLE like '%".$chat_admin."%'") or DIE (mysql_error());
while($info = mysql_fetch_array($data)){

echo "<tr><td><input type=radio name=admin value=".$info['NAME'].">".$info['NAME']."</td></tr>";
}
echo "<tr><td class=submit align=center><input type=Submit value=Submit></td></tr>";
echo "</form></table></div>";

?>
<? ob_flush(); ?>