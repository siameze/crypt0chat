<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#editCHAN{
position:relative;
margin-top:50px;
}

textarea {
width: 550px;
height: 250px;
}

</style>


<?php

require('../../../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$user = $_GET['name'];
$id = $_GET['id'];


echo "<div id=editCHAN align=center>";
echo "<hr>";
echo "<h1><center>Specify the reason for ".$user."'s banning below</center></h1>";
echo "<hr>";
echo "<h3>Enter reason below:</h3>";
echo "<form method=post action=ban_update.php?name=".$user."&id=".$id.">";
echo "<textarea name=Ban_Reason></textarea>";
echo "<br/><input type=submit name=Submit value=Submit /></form>";
echo "</div>";
?>