<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#manageUSERS{
position:relative;
margin-top:50px;
}

.centered-cell {
  text-align: center;
} 

</style>

<?php

session_start();

$now = time();
///////////////////////////////////////////////////////////
//If someone attempts to access the dashboard, they will be 
//kicked out and redirected to your chat login page
///////////////////////////////////////////////////////////

if(!$_SESSION['adminNAME']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=../../login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=../../login.php");

    }else{

require('../../../lib/config.php');
require('../img.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

///////////////////////////////////////////////////////
//Create Paging
///////////////////////////////////////////////////////

$start = 0;
$per_page = 10;

if(!isset($_GET['page']))
{
$page = 1;
}else
{
$page = $_GET['page'];
}
if($page<=1){
$start = 0;
}else{
$start = $page * $per_page - $per_page;
}

$banned = "AJAX_CHAT_BANNED";

$sql = "SELECT * FROM ajax_chat_registered_members WHERE ROLE like '%".$banned."%'";
$num_rows = mysql_num_rows(mysql_query($sql));
$num_pages = $num_rows / $per_page;
$sql .= " LIMIT $start, $per_page";
$total_pages = ceil($num_rows / $per_page);



echo "<div id=manageUSERS align=center>";
echo "<hr>";
echo "<h1> Banned User Management Dashboard</h1>";
echo "<hr>";

echo "<div align=center>";
echo "<h3>Enter the User's Name you want to find:</h3>";
echo "<form method=get action=search_results.php>";
echo "<label>Search For:</font> </label><input type=text name=query />";
echo "<input type=submit name=submit value='Search Users' />";
echo "</form>";
echo "</div>";

echo "<table border=1 width=100% align=center style=border-spacing:.5em;><th>Username</th><th>Banned By</th><th>Reason for Ban</th><th>Edit</th>";


///////////////////////////////////////////////////////
//Grabs Registration information
///////////////////////////////////////////////////////

$result = mysql_query($sql);

while($row = mysql_fetch_array($result)){ 

$id = $row['ID'];
$name = $row['NAME'];
$pass = $row['PASS'];
$role = $row['ROLE'];
$ban_reason = $row['BAN_REASON'];
$banned_by = $row['BANNED_BY'];

if($ban_reason == ""){
$text = "Click edit to specify reason for banning";
}else{
$text = $ban_reason;
}

if($banned_by == ""){
$text2 = "Click edit to enter the responsible Admin";
}else{
$text2 = $banned_by;
}
///////////////////////////////////////////////////////
//Allows managament of all the chats members
///////////////////////////////////////////////////////

echo "<tr>";
echo "<td class=centered-cell>" .$name. "</td>";
echo "<td class=centered-cell>".$text2."</td><td class=centered-cell>".$text."</td><td class=centered-cell><span><a href='ban_reason.php?name=" .$name. "&id=" .$id. "' title='edit reason for banning'>" .$edit. "</a></span></td></tr>";

}

echo "</table>";
echo "</div>";


//////////////////////////////////////////////////////////
//Handling Paging
//////////////////////////////////////////////////////////

$prev = $page - 1;
$next = $page + 1;
$first = "1";
$end = $total_pages;

echo"<hr>";

if($page != $total_pages){
$pagefwd = $b_next;
$pagelast = $b_last;
}else{
$pagefwd = "";
$pagelast = "";
}

if($page != 1){
$pageback = $b_back;
$pagestart = $b_start;
}else{
$pageback = "";
$pagestart = "";
}


echo "<center><a href='?page=$first'><b>$pagestart</b></a>&nbsp;&nbsp;";
echo "<a href='?page=$prev'><b>$pageback</b></a>&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<a href='?page=$next'><b>$pagefwd</b></a>&nbsp;&nbsp;";
echo "<a href='?page=$end'><b>$pagelast</b></a></center>";

echo "</td><td><center><b>Page ".$page." of ".$total_pages." </b></center></td></tr></table><div>";

  }

?>
<? ob_flush(); ?>