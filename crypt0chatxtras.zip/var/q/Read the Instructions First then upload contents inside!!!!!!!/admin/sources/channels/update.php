<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

</style>

<?php

require('../../../lib/config.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$id = $_GET['id'];
$user = $_GET['user'];
$role = $_GET['role'];

if($role !== "AJAX_CHAT_BANNED"){
$chanselect0 = "0";
$chanselect1 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect1'])))); 
$chanselect2 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect2']))));
$chanselect3 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect3']))));
$chanselect4 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect4']))));
$chanselect5 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect5']))));
$chanselect6 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect6']))));
$chanselect7 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect7']))));
$chanselect8 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chanselect8']))));
}else{
$chanselect9 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['bannedchannel']))));
}

mysql_query("UPDATE ajax_chat_registered_members SET CHANNELS='$chanselect0$chanselect1$chanselect2$chanselect3$chanselect4$chanselect5$chanselect6$chanselect7$chanselect8$chanselect9' WHERE id='$id'");

mysql_query("UPDATE ajax_chat_registered_members SET
CHANNEL1='$chanselect1',
CHANNEL2='$chanselect2',
CHANNEL3='$chanselect3',
CHANNEL4='$chanselect4',
CHANNEL5='$chanselect5',
CHANNEL6='$chanselect6',
CHANNEL7='$chanselect7',
CHANNEL8='$chanselect8',
CHANNEL9='$chanselect9' WHERE id='$id'");

echo "<center><h1>Please wait while we update ".$user."'s Channel Privilages...</h1></center>";
header("refresh:3;url=./chan-success.php");



?>
<? ob_flush(); ?>