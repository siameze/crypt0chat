<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#manageUSERS{
position:relative;
margin-top:50px;
z-index:3;
}

#ChanEdit{
position:relative;
top:-5px;
z-index:2;
}

#ChanShow{
position:relative;
top:15px;
z-index:1;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#paging{
position:relative;
bottom:-10px;
z-index:-1;
}

</style>

<?php


session_start();

$now = time();
///////////////////////////////////////////////////////////
//If someone attempts to access the dashboard, they will be 
//kicked out and redirected to your chat login page
///////////////////////////////////////////////////////////

if(!session_is_registered(adminNAME)){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=../../login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=../../login.php");

    }else{

require('../../../lib/data/channels.php');
require('../../../lib/config.php');
require('../img.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

///////////////////////////////////////////////////////
//Create Paging
///////////////////////////////////////////////////////

$start = 0;
$per_page = 10;

if(!isset($_GET['page']))
{
$page = 1;
}else
{
$page = $_GET['page'];
}
if($page<=1){
$start = 0;
}else{
$start = $page * $per_page - $per_page;
}

$query = mysql_real_escape_string(htmlentities(strip_tags(trim($_GET['query']))));
$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME like '%".$query."%' ORDER BY id ASC";
$num_rows = mysql_num_rows(mysql_query($sql));
$num_pages = $num_rows / $per_page;
$sql .= " LIMIT $start, $per_page";
$total_pages = ceil($num_rows / $per_page);

echo "<div id=manageUSERS align=center>";
echo "<hr>";
echo "<h1> User Search Results</h1>";
echo "<hr>";

echo "<div align=center>";
echo "<h3>Search Again?</h3>";
echo "<form method=get action=search_results.php>";
echo "<label>Search For:</font> </label><input type=text name=query />";
echo "<input type=submit name=submit value='Search Users' />";
echo "</form>";
echo "</div>";
 
if ($query == ""){
echo "<center><h3>Nothing was entered in the search box.</h2><h3>Please try again!</h3></center>";
}else if(mysql_num_rows(mysql_query($sql)) == 0){
echo "<center><h3>Sorry, there aren't any records of this user.</h2><h3>Please try again!</h3></center>";
}else{


///////////////////////////////////////////////////////////
//Channel Info
///////////////////////////////////////////////////////////

echo "<div id=ChanShow align=left>";
echo "<i><b>*Hover over the table names to reveal the actual channel name</b></i>";
echo "</div>";

///////////////////////////////////////////////////////////
//Channel Edit Link
///////////////////////////////////////////////////////////

echo "<div id=ChanEdit align=right>";
echo "<a href=chanedit.php><b>Edit Channel Names</b></a>";
echo "</div>";

echo "<table id=chanUSERS style=border-spacing:.75em; border=1 align=left><th>Username</th><th><span title=".$channels[0].">Main</span></th></th><th><span title=".$channels[1].">Chan 1</span></th><th><span title=".$channels[2].">Chan 2</span></th><th><span title=".$channels[3].">Chan 3</span></th><th><span title=".$channels[4].">Chan 4</span></th><th><span title=".$channels[5].">Chan 5</span></th><th><span title=".$channels[6].">Chan 6</span></th><th><span title=".$channels[7].">Chan 7</span></th><th><span title=".$channels[8].">Chan 8</span></th><th><span title=".$channels[9].">Banned</span></th>";

$result = mysql_query($sql);

while($row = mysql_fetch_array($result)){ 

$id = $row['ID'];
$user = $row['NAME'];
$pass = $row['PASS'];
$role = $row['ROLE'];

if($role !== "AJAX_CHAT_BANNED"){

if(empty($row['CHANNEL1'])){
$chan1 = "";
}else{
$chan1 = "checked";
}

if(empty($row['CHANNEL2'])){
$chan2 = "";
}else{
$chan2 = "checked";
}

if(empty($row['CHANNEL3'])){
$chan3 = "";
}else{
$chan3 = "checked";
}

if(empty($row['CHANNEL4'])){
$chan4 = "";
}else{
$chan4 = "checked";
}

if(empty($row['CHANNEL5'])){
$chan5 = "";
}else{
$chan5 = "checked";
}

if(empty($row['CHANNEL6'])){
$chan6 = "";
}else{
$chan6 = "checked";
}

if(empty($row['CHANNEL7'])){
$chan7 = "";
}else{
$chan7 = "checked";
}

if(empty($row['CHANNEL8'])){
$chan8 = "";
}else{
$chan8 = "checked";
}

///////////////////////////////////////////////////////
//Allows managament of all the chats members
///////////////////////////////////////////////////////

echo "<form method=post action=update.php?id=".$id."&user=".$user."&role=".$role.">";
echo "<tr><td width=150px><center>".$user."</center></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect0 value=0  checked ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect1 value=,1  ".$chan1." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect2 value=,2  ".$chan2." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect3 value=,3  ".$chan3." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect4 value=,4  ".$chan4." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect5 value=,5  ".$chan5." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect6 value=,6  ".$chan6." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect7 value=,7  ".$chan7." ></td>";
echo "<td width=100px align=center><input type=checkbox name=chanselect8 value=,8  ".$chan8." ></td>";
echo "<td width=100px align=center><input type=checkbox name=bannedchannel disabled></td>";
echo "<td class=submit align=center><input type=Submit value=Submit>";
echo "</td></tr></form>";

}else{

echo "<form method=post action=update.php?id=".$id."&user=".$user."&role=".$role.">";
echo "<tr><td width=150px><center>".$user."</center></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox disabled></td>";
echo "<td width=100px align=center><input type=checkbox name=bannedchannel value=9 checked></td>";
echo "<td class=submit align=center><input type=Submit value=Submit>";
echo "<td></tr></form>";
      }
   }

echo "</table>";

//////////////////////////////////////////////////////////
//Handling Paging
//////////////////////////////////////////////////////////

$prev = $page - 1;
$next = $page + 1;
$first = "1";
$end = $total_pages;

echo"<hr>";

if($page != $total_pages){
$pagefwd = $b_next;
$pagelast = $b_last;
}else{
$pagefwd = "";
$pagelast = "";
}

if($page != 1){
$pageback = $b_back;
$pagestart = $b_start;
}else{
$pageback = "";
$pagestart = "";
}

echo "<div id=paging align=center>";
echo "<a href='?query=".$query."&page=$first'><b>$pagestart</b></a>&nbsp;&nbsp;";
echo "<a href='?query=".$query."&page=$prev'><b>$pageback</b></a>&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<a href='?query=".$query."&page=$next'><b>$pagefwd</b></a>&nbsp;&nbsp;";
echo "<a href='?query=".$query."&page=$end'><b>$pagelast</b></a>";
echo "<br/>";
echo "<b>Page ".$page." of ".$total_pages." </b><div>";
  
        }

   }

?>
<? ob_flush(); ?>