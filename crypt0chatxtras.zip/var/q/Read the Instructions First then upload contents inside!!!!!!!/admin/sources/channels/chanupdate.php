<? ob_start(); ?>

<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>

<?php

$chan_id = $_GET['chanid'];

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

require('../../../lib/config.php');
require('../../../lib/data/channels.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$data = mysql_query("SELECT * FROM ajax_chat_channels WHERE chan_ID='$chan_id'") or die(mysql_error());
$info = mysql_fetch_array( $data );

if($chan_id == "0"){

$default_chan_name = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['new_chan_name']))));

echo "<div align=center><h1>";
echo 'Your new channel name:<br/>"'.$default_chan_name.'" <br/>was accepted!';
echo '<br/><br/><br/>The "channels.php" file was updated with your submission!</h1>';
echo "<BR>";
echo "<a href='./dashboard.php' style=text-decoration:none><strong>Click here to return to the<br> Channel Management Dashboard</strong></a>";
echo "</div>";

    }else{

$default_chan_name = $channels[0];
$chan_name = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['new_chan_name']))));

$sql="UPDATE ajax_chat_channels SET 
chan_NAME='{$chan_name}'
WHERE chan_ID='$chan_id'";
$result = mysql_query($sql); 

// if successfully updated.
if($result)
{

echo "<div align=center><h1>";
echo 'Your new channel name:<br/>"'.$chan_name.'" <br/>was accepted!';
echo '<br/><br/><br/>The "channels.php" file was updated with your submission!</h1>';
echo "<BR>";
echo "<a href='./dashboard.php' style=text-decoration:none><strong>Click here to return to the<br> Channel Management Dashboard</strong></a>";
echo "</div>";
    
    }
}

$chaninfo = "../../../lib/data/channels.php";
unlink($chaninfo);

 $Handle = fopen($chaninfo, 'wb');
 $Data = "<?php\n";  
 fwrite($Handle, $Data); 
 $Data = "//You no longer have to edit channels here,\n //Use the admin script to make your channel changes.\n";   
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$channels = array();\n";  
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "// Your Channels List:\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$channels[0] = '$default_chan_name';\n"; 
 fwrite($Handle, $Data); 

$chan_data = mysql_query("SELECT * FROM ajax_chat_channels") or die ('Error: '.mysql_error ());
while($chan_info = mysql_fetch_array( $chan_data )){

$chanid = $chan_info['chan_ID'];
$channame = $chan_info['chan_NAME'];

 $Data = "\$channels[$chanid] = '$channame';\n"; 
 fwrite($Handle, $Data);

}


 $Data = "\n";  
 fwrite($Handle, $Data);
 $Data = "?>";  
 fwrite($Handle, $Data);
 fclose($Handle);
 chmod($chaninfo, 0755);


?>
<? ob_flush(); ?>