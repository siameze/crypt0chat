<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#editCHAN{
position:relative;
margin-top:50px;
}

</style>


<?php

$chan_name = $_GET['channelname'];


echo "<div id=editCHAN align=center>";
echo "<hr>";
echo "<h1><center>Change ".$chan_name."'s channel name below</center></h1>";
echo "<i>*No spaces between words please</i>";
echo "<hr><br/>";

echo "<form method=post action=chanupdate.php?chanid=".$_GET['chanid'].">";
echo "Enter your new channel's name:<br/><input type=text name=new_chan_name>";
echo "<input type=submit name=Submit value=Submit /></form>";
echo "</div>";
?>