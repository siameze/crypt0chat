<? ob_start(); ?>
	<style type="text/css">
a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

body{
font-family:Arial,Helvetica,sans-serif;
}
     </style>

<?php

$id = $_GET['id'];
$user = $_GET['user'];

///////////////////////////////////////////////////////////////
//Connect to Chat Database:
///////////////////////////////////////////////////////////////

require('../../../lib/config.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']); 


///////////////////////////////////////////////////////
//Delete users.php
///////////////////////////////////////////////////////

$userinfo = "../../../lib/data/users.php";
unlink($userinfo);

///////////////////////////////////////////////////////
//Begin rebuilding users.php (Guest information below)
///////////////////////////////////////////////////////

 $Handle = fopen($userinfo, 'wb');
 $Data = "<?php\n";  
 fwrite($Handle, $Data); 
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "//You no longer have to make edits to this file."; 
 fwrite($Handle, $Data);   
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "//Use the Admin Script to make your needed changes!";   
 fwrite($Handle, $Data);  
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "\n";   
 fwrite($Handle, $Data);  
 $Data = "\$users = array();\n";  
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "// Default Guest User:\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0] = array();\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['userRole'] = AJAX_CHAT_GUEST;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['userName'] = null;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['password'] = null;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['channels'] = array(0);\n";   
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data);

$update = mysql_query("SELECT * FROM ajax_chat_registered_members") or die(mysql_error());
while($update2 = mysql_fetch_array( $update )){

$user_id = $update2['ID'];
$user_name = $update2['NAME'];
$user_pass = $update2['PASS'];
$user_role = $update2['ROLE'];
$user_chanlist = $update2['CHANNELS']; 

/////////////////////////////////////////////////////////
//Writes all registered members information to users.php
/////////////////////////////////////////////////////////
    
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "// $user_name:\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id] = array();\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['userRole'] = $user_role;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['userName'] = '$user_name';\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['password'] = '$user_pass';\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['channels'] = array($user_chanlist);\n"; 
 fwrite($Handle, $Data);

}

///////////////////////////////////////////////////////
//Closes and saves users.php
///////////////////////////////////////////////////////
   
 $Data = "\n";  
 fwrite($Handle, $Data);
 $Data = "?>";  
 fwrite($Handle, $Data);
 fclose($Handle);
 chmod($userinfo, 0755);    
	
    echo "<center><h1>The Channel privilages for ".$user." were saved and updated!</h1><br/><b>Returning you to the channel management dashboard...</b>";
    header("refresh:3;url=./dashboard.php");	
?>	
<? ob_flush(); ?>