<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#chanUSER{
position:relative;
margin-top:50px;
}

</style>


<?php

require('../../../lib/data/channels.php');
require('../../../lib/config.php');

$id = $_GET['id'];
$user = $_GET['user'];

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

echo "<div id=chanUSER>";
echo "<hr>";
echo "<center><h1>Channel Access for ".$user."</h1>";
echo "<b>First channel enabled by default</b></center>";
echo "<hr>";

echo "<table border=1 align=center style=border-spacing:1em;>";
echo "<form method=post action=update.php?id=".$id."&user=".$user.">";

echo "<tr><td><input type=checkbox name=access[] value=0 disabled=disabled>".$channels[0]."</td></tr>";

$checkchans = mysql_query("SELECT * FROM ajax_chat_registered_members WHERE id='$id'");
$chaninfo = mysql_fetch_array( $checkchans );

if(!empty($chaninfo['CHANNEL1'])){
$chan1 = "checked";
}

if(!empty($chaninfo['CHANNEL2'])){
$chan2 = "checked";
}

if(!empty($chaninfo['CHANNEL3'])){
$chan3 = "checked";
}

if(!empty($chaninfo['CHANNEL4'])){
$chan4 = "checked";
}

if(!empty($chaninfo['CHANNEL5'])){
$chan5 = "checked";
}

if(!empty($chaninfo['CHANNEL6'])){
$chan6 = "checked";
}

if(!empty($chaninfo['CHANNEL7'])){
$chan7 = "checked";
}

if(!empty($chaninfo['CHANNEL8'])){
$chan8 = "checked";
}

if(!empty($chaninfo['CHANNEL9'])){
$chan9 = "checked";
}

echo "<tr><td><input type=checkbox name=chanselect1 value=,1  ".$chan1." >".$channels[1]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect2 value=,2  ".$chan2." >".$channels[2]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect3 value=,3  ".$chan3." >".$channels[3]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect4 value=,4  ".$chan4." >".$channels[4]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect5 value=,5  ".$chan5." >".$channels[5]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect6 value=,6  ".$chan6." >".$channels[6]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect7 value=,7  ".$chan7." >".$channels[7]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect8 value=,8  ".$chan8." >".$channels[8]."</td></tr>";
echo "<tr><td><input type=checkbox name=chanselect9 value=,9  ".$chan9." >".$channels[9]."</td></tr>";


echo "<tr><td><center><input type=Submit value=Submit></center></form></td></tr></table>";
echo "</div>";



?>
