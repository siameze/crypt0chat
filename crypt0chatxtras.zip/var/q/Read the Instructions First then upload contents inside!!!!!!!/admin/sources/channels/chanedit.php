<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#manageCHAN{
position:relative;
margin-top:50px;
}

</style>

<?php

require('../../../lib/data/channels.php');
require('../../../lib/config.php');
require('../img.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

echo "<div id=manageCHAN >";
echo "<hr>";
echo "<h1><center>Channel Management Dashboard</center></h1>";
echo "<h3><center>Edit your channel names below</center></h3>";
echo "<hr><br/>";

echo "<table id=listCHAN style=border-spacing:1em; border=1 align=center>";
echo "<th>Channels List</th>";
echo "<th>Edit</th>";

echo "<tr><td align=center width=150>".$channels[0]."</td><td width=50><a href=./chan-rename.php?channelname=".$channels[0]."&chanid=0>".$edit."</a></td></tr>";

$chan_data = mysql_query("SELECT * FROM ajax_chat_channels") or die ('Error: '.mysql_error ());
while($chan_info = mysql_fetch_array( $chan_data )){

$chanid = $chan_info['chan_ID'];
$channame = $chan_info['chan_NAME'];

echo "<tr><td align=center width=150>".$channame."</td><td width=50><a href=./chan-rename.php?channelname=".$channame."&chanid=".$chanid.">".$edit."</a></td></tr>";
}
echo "</table></div>";
?>