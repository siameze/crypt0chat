<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>

<?php

session_start();

$id=$_GET['id'];
$chatUSER = $_GET['name'];
$chatPASS = $_GET['pass'];
$chatPASS2 = $_GET['pass'];
$chatROLE = $_GET['role'];


require('../../../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

$data = mysql_query("SELECT * FROM ajax_chat_registered_members WHERE id='$id'") or die(mysql_error());
while($info = mysql_fetch_array( $data )){

$name = $info['NAME'];

 if($id && $chatUSER){

echo "<center><h1>Modify " .$name. "'s Name Below</h1></center>";

echo "<form action=update.php?id=" .$id. " method=post enctype=multipart/form-data  OnSubmit=return ConfirmForm();>";
echo "<table border=1 align=center>";
echo "<tr><td>Username:</td><td><input type=text name=chatUSER value=" .$chatUSER. "></td></tr>";
echo "<tr><td></td><td><center><input type=submit name=Submit value=Update></center></td></tr>";
echo "</table>";
echo "</form>";

}else if($id && $chatPASS){

echo "<center><h1>Modify " .$name. "'s Password Below</h1></center>";

echo "<form action=update.php?id=" .$id. " method=post enctype=multipart/form-data  OnSubmit=return ConfirmForm();>";
echo "<table border=1 align=center>";
echo "<tr><td>Password:</td><td><input type=password name=chatPASS value=" .$chatPASS. "></td></tr>";
echo "<tr><td>Confirm Password:</td><td><input type=password name=chatPASS2 value=" .$chatPASS2. "></td></tr>";
echo "<tr><td></td><td><center><input type=submit name=Submit value=Update></center></td></tr>";
echo "</table>";
echo "</form>";

}else if($id && $chatROLE){

if ($chatROLE == "AJAX_CHAT_ADMIN"){
$role = "Administrator";
$groupcolor = "red";
}else if ($chatROLE == "AJAX_CHAT_MODERATOR"){
$role = "Moderator";
$groupcolor = "green";
}else if ($chatROLE == "AJAX_CHAT_VIP"){
$role = "V.I.P.";
$groupcolor = "00FFFF";
}else if ($chatROLE == "AJAX_CHAT_USER"){
$role = "Member";
$groupcolor = "silver";
}else{
$role = "Banned";
$groupcolor = "#500000";
}

echo "<center><h1>" .$name. " is currently part of <br/>your chatroom's <font color=" .$groupcolor. "> " .$role. "</font> User Role Group.<h1><h3>Make the proper selection below to update<br/> " .$name. "'s new User Role Group.</h3></center>";

echo "<form action=update.php?id=" .$id. " method=post enctype=multipart/form-data  OnSubmit=return ConfirmForm();>";
echo "<table border=1 align=center width=15%";
echo "<tr al><td><center>Select the correct User Role:</center></td></tr>";
echo "<tr><td><input type=radio name=chatROLE value=AJAX_CHAT_ADMIN>Administrator</td></tr>";
echo "<tr><td><input type=radio name=chatROLE value=AJAX_CHAT_MODERATOR>Moderator</td></tr>";
echo "<tr><td><input type=radio name=chatROLE value=AJAX_CHAT_VIP>V.I.P.</td></tr>";
echo "<tr><td><input type=radio name=chatROLE value=AJAX_CHAT_USER>Member</td></tr>";
echo "<tr><td><input type=radio name=chatROLE value=AJAX_CHAT_BANNED>Banned</td></tr>";
echo "<tr align=center><td><input type=submit name=Submit value=Update></td></tr>";
echo "</td></tr>";
echo "</table>";
echo "</form>";

}else{

echo "ERROR";

       }
}

?>
<? ob_flush(); ?>