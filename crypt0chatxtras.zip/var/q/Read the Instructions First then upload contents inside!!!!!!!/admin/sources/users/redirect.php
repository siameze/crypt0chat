<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#manageUSERS{
position:relative;
margin-top:50px;
}

.centered-cell {
  text-align: center;
} 

</style>

<?php

session_start();

$now = time();
///////////////////////////////////////////////////////////
//If someone attempts to access the dashboard, they will be 
//kicked out and redirected to your chat login page
///////////////////////////////////////////////////////////

if(!session_is_registered(adminNAME)){
  echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=../../login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=../../login.php");

    }else{

echo "<center><h1>End of Results.<br/>Redirecting you to the first page.<h1></center>";
header('refresh:3;url=./dashboard.php?page=1');
}
?>