<? ob_start(); ?>
<script type="text/javascript"  src="http://code.jquery.com/jquery.min.js"></script>

<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

#manageUSERS{
position:relative;
margin-top:50px;
}

.centered-cell {
  text-align: center;
} 

#usersBUTTON{
position:absolute;
right:0px;
top:157px;
}

</style>

<script type="text/javascript">
$(document).ready(function(e) {

    $(".confirm").on("click", function(event){
            var ConfirmLabel;
            if(isset($(this).attr("confirmLabel"))){
                ConfirmLabel = $(this).attr("confirmLabel");
            }else{
                ConfirmLabel= "Are You sure?";
            }
            if(confirm(ConfirmLabel)){
               return true;
            } else {
                return false;
			}
	});
});

function isset() {
    var a = arguments,
    l = a.length,
    i = 0,
    undef;
    /////////////
    if (l === 0) {
        throw new Error('Empty isset');
    }
    /////////////
    while (i !== l) {
        if (a[i] === undef || a[i] === null) {
            return false;
        }
        i++;
    }
    return true;
}
</script>

<?php 

session_start();

$now = time();
///////////////////////////////////////////////////////////
//If someone attempts to access the dashboard, they will be 
//kicked out and redirected to your chat login page
///////////////////////////////////////////////////////////

if(!$_SESSION['adminNAME']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=../../login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=../../login.php");

    }else{

require('../../../lib/config.php');
require('../img.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

///////////////////////////////////////////////////////
//Create Paging
///////////////////////////////////////////////////////

$start = 0;
$per_page = 10;

if(!isset($_GET['page']))
{
$page = 1;
}else
{
$page = $_GET['page'];
}
if($page<=1){
$start = 0;
}else{
$start = $page * $per_page - $per_page;
}

$sql = "SELECT * FROM ajax_chat_registered_members ORDER BY id ASC";
$num_rows = mysql_num_rows(mysql_query($sql));
$num_pages = $num_rows / $per_page;
$sql .= " LIMIT $start, $per_page";
$total_pages = ceil($num_rows / $per_page);



echo "<div id=manageUSERS align=center>";
echo "<hr>";
echo "<h1> User Management Dashboard</h1>";
echo "<hr>";

//////////////////////////////////////////////////////////
//User Search
//////////////////////////////////////////////////////////

echo "<div align=center>";
echo "<h3>Enter the User's Name or UserRole you want to find:</h3>";
echo "<form method=get action=search_results.php>";
echo "<label>Search For:</font> </label><input type=text name=query />";
echo "<input type=submit name=submit value='Search Users' />";
echo "</form>";
echo "</div>";

echo "<div id=usersBUTTON align=left>";
echo "<form method=link action=rebuild_users.php>";
echo "<input type=submit value='Rebuild Users.PHP File'>";
echo "</form>";
echo "</div>";

echo "<table border=1 width=100% align=center style=border-spacing:.75em;><th>Username</th><th>&nbsp;</th><th>Password</th><th>&nbsp;</th><th>Current Role</th><th>&nbsp;</th><th>&nbsp;</th>";

///////////////////////////////////////////////////////
//Grabs Registration information
///////////////////////////////////////////////////////

$result = mysql_query($sql);

while($row = mysql_fetch_array($result)){ 

$id = $row['ID'];
$name = $row['NAME'];
$pass = $row['PASS'];
$role = $row['ROLE'];

///////////////////////////////////////////////////////
//Allows managament of all the chats members
///////////////////////////////////////////////////////

echo "<tr>";
echo "<td class=centered-cell>" .$name. "</td><td><span><a href='edit.php?name=" .$name. "&id=" .$id. "' title='edit this users name'>" .$edit. "</a></span></td>";
echo "<td class=centered-cell>(hidden)</td><td><span><a href='edit.php?pass=" .md5($pass). "&id=" .$id. "' title='edit this users password'>" .$edit. "</a></span></td>";
echo "<td class=centered-cell>" .$role. "</td><td><span><a href='edit.php?role=" .$role. "&id=" .$id. "' title='edit this users role'>" .$edit. "</a></span></td>";
echo "<td class=centered-cell><span><a href='delete.php?name=" .$name. "&id=" .$id."'  class='confirm' confirmLabel='Are you sure you want to delete this account \t\n belonging to " .$name. "?'>" .$delete. " </a></span></td></tr>";

}

echo "</table>";
echo "</div>";


//////////////////////////////////////////////////////////
//Handling Paging
//////////////////////////////////////////////////////////

$prev = $page - 1;
$next = $page + 1;
$first = "1";
$end = $total_pages;

echo"<hr>";

if($page != $total_pages){
$pagefwd = $b_next;
$pagelast = $b_last;
}else{
$pagefwd = "";
$pagelast = "";
}

if($page != 1){
$pageback = $b_back;
$pagestart = $b_start;
}else{
$pageback = "";
$pagestart = "";
}


echo "<center><a href='?page=$first'><b>$pagestart</b></a>&nbsp;&nbsp;";
echo "<a href='?page=$prev'><b>$pageback</b></a>&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<a href='?page=$next'><b>$pagefwd</b></a>&nbsp;&nbsp;";
echo "<a href='?page=$end'><b>$pagelast</b></a></center>";

echo "</td><td><center><b>Page ".$page." of ".$total_pages." </b></center></td></tr></table><div>";

}


?>
<? ob_flush(); ?>