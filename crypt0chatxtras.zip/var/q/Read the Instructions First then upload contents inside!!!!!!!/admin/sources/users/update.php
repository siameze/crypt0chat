<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>

<?php

session_start();

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

require('../../../lib/config.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);


///////////////////////////////////////////////////////
//Pull's and saves variables from previous page
///////////////////////////////////////////////////////

$id=$_GET['id'];
$chatUSER = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatUSER']))));
$chatPASS = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatPASS']))));
$chatPASS2 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatPASS2']))));
$chatROLE = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatROLE']))));

///////////////////////////////////////////////////////
//Obtain's Users Registration Info and stores it below
///////////////////////////////////////////////////////

$data = mysql_query("SELECT * FROM ajax_chat_registered_members WHERE id='$id'") or die(mysql_error());
$info = mysql_fetch_array( $data );

///////////////////////////////////////////////////////
//Update User's Name
///////////////////////////////////////////////////////

if ($id && $chatUSER && $chatROLE == "" && $chatPASS == ""){
$sql="UPDATE ajax_chat_registered_members SET 
NAME='{$chatUSER}'
WHERE id='$id'";
$result = mysql_query($sql); 

// if successfully updated.
if($result)
{

echo "<title>Your update was successful!</title>";
echo "<div align=center><h1>";
echo $chatUSER; 
echo "'s name was successfully updated!</h1>";
echo "<BR>";
    
    }

///////////////////////////////////////////////////////////
//Checks to see if the passwords match, if Not gives Error
///////////////////////////////////////////////////////////

  }else if ($id && ($chatPASS !== $chatPASS2)){

echo "<title>ERROR!</title>";
echo "<div align=center><h1>";
echo "The passwords entered don't match!</h1>";
echo "<BR>";

///////////////////////////////////////////////////////
//If matches, continue to update User's new passsword
///////////////////////////////////////////////////////

}else if ($id && ($chatPASS == $chatPASS2) && $chatROLE == "" && $chatNAME == ""){

$sql="UPDATE ajax_chat_registered_members SET 
PASS='{$chatPASS}'
WHERE id='$id'";
$result = mysql_query($sql); 

// if successfully updated.
if($result)
{

echo "<title>Your update was successful!</title>";
echo "<div align=center><h1>";
echo $info['NAME'];
echo "'s password was successfully updated!</h1>";
echo "<BR>";

    }

///////////////////////////////////////////////////////
//Update User's chat Group Role Rank
///////////////////////////////////////////////////////

  }else if ($id && $chatROLE  && $chatPASS == "" && $chatNAME == ""){

$sql="UPDATE ajax_chat_registered_members SET 
ROLE='{$chatROLE}'
WHERE id='$id'";
$result = mysql_query($sql); 

// if successfully updated.
if($result)
{

if ($chatROLE == "AJAX_CHAT_ADMIN"){
$role = "Administrator";
$groupcolor = "red";
}else if ($chatROLE == "AJAX_CHAT_MODERATOR"){
$role = "Moderator";
$groupcolor = "green";
}else if ($chatROLE == "AJAX_CHAT_VIP"){
$role = "V.I.P.";
$groupcolor = "#00FFFF";
}else if ($chatROLE == "AJAX_CHAT_DBMOD"){
$role = "Database Mod";
$groupcolor = "#FFBF00";
}else if ($chatROLE == "AJAX_CHAT_USER"){
$role = "Member";
$groupcolor = "silver";
}else{
$role = "Banned";
$groupcolor = "#500000";
}

echo "<div align=center>";

if ($role == "Banned"){
echo "<h1>";
echo $info['NAME'];
echo " is now <font color=" .$groupcolor. ">Banned</font> from your chat!</h1><br/><h3> Make sure you also <b><font color=red>kick/ban</font></b> " .$info['NAME']. " in the chatroom as well.</h3>";
echo "<h4>It would be best leave  " .$info['NAME']. "'s  information from the database for record keeping purposes</h4>";

}else{

echo "<h1>";
echo $info['NAME'];
echo " was successfully updated<br/> to the <font color=" .$groupcolor. ">" .$role. " </font>user group!</h1><br/><h3>If " .$info['NAME']. " is currently online, make sure that <br/>he/she logs out then log back into the chat for the visual changes to take effect.</h3>";
echo "<BR>";
        }

    }

}


echo "<a href='./dashboard.php' style=text-decoration:none><strong>Click here to return to the<br> User Management Dashboard</strong></a>";
echo "</div>";


///////////////////////////////////////////////////////
//Delete users.php
///////////////////////////////////////////////////////

$userinfo = "../../../lib/data/users.php";
unlink($userinfo);



///////////////////////////////////////////////////////
//Begin rebuilding users.php (Guest information below)
///////////////////////////////////////////////////////

 $Handle = fopen($userinfo, 'wb');
 $Data = "<?php\n";  
 fwrite($Handle, $Data); 
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "//You no longer have to make edits to this file."; 
 fwrite($Handle, $Data);   
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "//Use the Admin Script to make your needed changes!";   
 fwrite($Handle, $Data);  
 $Data = "\n";   
 fwrite($Handle, $Data); 
 $Data = "\n";   
 fwrite($Handle, $Data);  
 $Data = "\$users = array();\n";  
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "// Default Guest User:\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0] = array();\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['userRole'] = AJAX_CHAT_GUEST;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['userName'] = null;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['password'] = null;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[0]['channels'] = array(0);\n";   
 fwrite($Handle, $Data); 
 $Data = "\n"; 
 fwrite($Handle, $Data);


$update = mysql_query("SELECT * FROM ajax_chat_registered_members") or die(mysql_error());
while($update2 = mysql_fetch_array( $update )){

$user_id = $update2['ID'];
$user_name = $update2['NAME'];
$user_pass = $update2['PASS'];
$user_role = $update2['ROLE'];

/////////////////////////////////////////////////////////
//Writes all registered members information to users.php
/////////////////////////////////////////////////////////
    
 $Data = "\n"; 
 fwrite($Handle, $Data); 
 $Data = "// $user_name:\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id] = array();\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['userRole'] = $user_role;\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['userName'] = '$user_name';\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['password'] = '$user_pass';\n"; 
 fwrite($Handle, $Data); 
 $Data = "\$users[$user_id]['channels'] = array(0,1);\n"; 
 fwrite($Handle, $Data);

}

///////////////////////////////////////////////////////
//Closes and saves users.php
///////////////////////////////////////////////////////
   
 $Data = "\n";  
 fwrite($Handle, $Data);
 $Data = "?>";  
 fwrite($Handle, $Data);
 fclose($Handle);
 chmod($userinfo, 0755);


?>
<? ob_flush(); ?>