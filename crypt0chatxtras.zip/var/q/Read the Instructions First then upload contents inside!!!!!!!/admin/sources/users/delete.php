<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

</style>


<?php 

session_start();

$now = time();

if(!session_is_registered(adminNAME)){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=./login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=./login.php");

    }else{


$id=$_GET['id'];
$name = $_GET['name'];

require('../../../lib/config.php');

echo "<script type=text/javascript>";
echo "alert(Do you really want to delete this user?)";
echo "</script>";


///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

mysql_query("DELETE FROM ajax_chat_registered_members WHERE id='$id'") or die(mysql_error());

echo "<div align=center><h1>";
echo $name;
echo "'s information was deleted from the database.</h1>";
echo "rediecting you back to the user management dashboard...";
echo "</div>";
header("refresh:4;url=./dashboard.php");

}

?>
<? ob_flush(); ?>

