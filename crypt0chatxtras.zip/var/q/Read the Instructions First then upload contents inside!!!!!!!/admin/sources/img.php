<?php

$edit = "<center><img src=../../img/edit.png></center>";
$delete = "<center><img src=../../img/delete.png></center>";

$b_start = "<img src=../../img/start.png width=30px height=30px>";
$b_back = "<img src=../../img/back.png width=30px height=30px>";
$b_next = "<img src=../../img/next.png width=30px height=30px>";
$b_last = "<img src=../../img/last.png width=30px height=30px>";

?>