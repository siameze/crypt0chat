<? ob_start(); ?>

<script type="text/javascript"  src="http://code.jquery.com/jquery.min.js"></script>

<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#register{
position:relative;
margin-top:50px;
}

</style>

<script>

$(document).ready(function()
    {
        $('input:submit').attr("disabled", true);
        var textCounter = false;
        $('input:text, textarea').keyup(check_submit);
        $('select').change(check_submit);
        
        function check_submit() {
            $('input:text, textarea, select').each(function()
              {
                if ($(this).val().length == 0) {
                    textCounter = true;
                    return false;
                   }
                else {
                    textCounter = false;
                }
             });
            
            $('input:submit').attr("disabled", textCounter);
        }
    });


</script>

<?php

session_start();

$now = time();

if(!$_SESSION['adminNAME']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=../../login.php");
session_destroy();

} else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=./login.php");

    }else{

echo "<div id=register align=center>";
echo "<hr><h1>New User Registration Dashboard</h1><hr>";
echo "<form action=reg-results.php method=post enctype=multipart/form-data  OnSubmit=return ConfirmForm();>";
echo "<table><br><br><strong>Fill out the form completely.</strong><br><br>";
echo "<tr><td>Username:</td><td> <input type=text name=chatUSER></td></tr>";
echo "<tr><td>Password: </td><td><input type=password name=chatPASS></td></tr>";
echo "<tr><td>Confirm Password: </td><td><input type=password name=chatPASS2></td></tr>";
echo "<tr><td>";
echo "<tr><td></td><td><input align=center type=submit id=submit name=submit value=Register disabled=disabled /></td></tr></table>";
echo "</form></div>";


}
?>


<script language="JavaScript">

function ConfirmForm()

{

      return confirm("  Make sure all is correct." + 

                   "  Click OK to continue your submission or Cancel to abort.  ");

}

</script>

<? ob_flush(); ?>