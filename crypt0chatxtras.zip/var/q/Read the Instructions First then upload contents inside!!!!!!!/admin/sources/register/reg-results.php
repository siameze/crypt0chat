<? ob_start(); ?>

	<style type="text/css">

body{ 
font-family:Arial,Helvetica,sans-serif;
}
     </style>

<?php
///////////////////////////////////////////////////////////////
//AJAX CHAT Regsistration Script by -SyN-. 
//No More users.php manual editing. 
//This script does it for you!
//http://clubsyn-x-treme.com
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//Connect to Chat Database:
///////////////////////////////////////////////////////////////

require('../../../lib/config.php');

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']); 

///////////////////////////////////////////////////////////////
//Illegal Character Detection
///////////////////////////////////////////////////////////////

if((preg_match('/[\'^�$%&*()}{@#~?><>,|=+�]/', $_POST['chatUSER'])) || (preg_match('/[\'^�$%&*()}{@#~?><>,|=+�]/', $_POST['chatPASS'])) || (preg_match('/[\'^�$%&*()}{@#~?><>,|=+�]/', $_POST['chatPASS2']))){

   echo "<title>Registration ERROR!</title>";
   echo "<br><center><h2>ERROR!</h2>";
   echo "<strong>Special Characters <b>ARE NOT ALLLOWED!</b><br/>Characters allowed are: A-Z a-z 0-9.<br/> Characters _ and - may also be used.";
   echo "<br/><br>";
   echo "Please go back and try again!</strong>";
   echo "<br><br><a href=./register.php>Go back!</center></a>";

}else{

///////////////////////////////////////////////////////////////
//Get Info from Registration form
///////////////////////////////////////////////////////////////

$chatUSER = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatUSER']))));
$chatPASS = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatPASS']))));
$chatPASS2 = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['chatPASS2']))));

}

//////////////////////////////////////////////////////////////////
// If passwords do't Match:
//////////////////////////////////////////////////////////////////

if ($chatPASS !== $chatPASS2){

   echo "<title>Registration ERROR!</title>";
   echo "<br><br><br>";
   echo "<center><strong>Your passwords don't match.";
   echo "<br/>";
   echo "Please go back and use matching passwords!</strong>";
   echo "<br><br><br><a href=./register.php>Go back!</center></a>";
}

///////////////////////////////////////////////////////////////////
//If passwords matches, proceed with saving the information
///////////////////////////////////////////////////////////////////

if($chatPASS === $chatPASS2){

///////////////////////////////////////////////////////////////
//Insert Registration info into Mysql
///////////////////////////////////////////////////////////////
         
$order = "INSERT INTO ajax_chat_registered_members
			(NAME, PASS)
			VALUES
            ('$chatUSER',
			 '$chatPASS')";
			 
$result = mysql_query($order);

if($result){

////////////////////////////////////////////////////////////////
//Fetches User ID from Mysql Table
////////////////////////////////////////////////////////////////

$data = mysql_query("SELECT ID FROM ajax_chat_registered_members ORDER BY id DESC LIMIT 1") or die(mysql_error());

$info = mysql_fetch_array( $data );

$id = $info['ID'];

////////////////////////////////////////////////////////////////
//First person registering (Should be the chat Admin) gets 
//AJAX_CHAT_ADMIN
////////////////////////////////////////////////////////////////

if ($id <= 1 ){
  $role = "AJAX_CHAT_ADMIN";
}else{
  $role = "AJAX_CHAT_USER";
}

/////////////////////////////////////////////////////////////////
//Save UserRole in Mysql
/////////////////////////////////////////////////////////////////

mysql_query("UPDATE ajax_chat_registered_members SET ROLE='$role' WHERE id='$id'");

//////////////////////////////////////////////////////////////////
//Success Msg Start:
//////////////////////////////////////////////////////////////////

    echo "<center><h1>Please wait while we update<br/>our database with your account informaton...</h1></center>";
    header("refresh:5;url=./reg-success.php");

}else{

//////////////////////////////////////////////////////////////////
//Duplicate Username Error!
///////////////////////////////////////////////////////////////////

	echo "<br><br><br><center><strong>The Username: <br>\" $chatUSER \"<br> is already in our user database.<br><br>";
    echo "Please go back and use a differnt name.</strong>";
    echo "<br><br><br><a href=./register.php>Go back!</a></center>";

     }
   }

?>

<? ob_flush(); ?>