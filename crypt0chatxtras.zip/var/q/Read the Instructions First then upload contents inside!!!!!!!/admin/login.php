<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

#AdminLogin{
position:relative;
margin-top:50px;
width:100%;
}

.login{
width:150px;
}

</style>

<?php 

session_start();
session_destroy();

echo "<div id=AdminLogin align=center>";
echo "<hr><h1>AJAX CHAT Administration Log in<hr></h1><br/><br/><br/><br/>";
echo "<div class=login align=left>";
echo "<form method=post action=check_admin_login.php>";
echo "Username: <input name=adminNAME type=text /><br/>";
echo "Password: <input name=adminPASS type=password /><br/>";
echo "<input type=submit name=Submit value=Login /></form>";
echo "</div></div>";


?>
<? ob_flush(); ?>