<?php

$filename = "../syns_mods/admin_install.php";


if (file_exists($filename)) {
    unlink($filename);
}

?>

<!DOCTYPE html>

<html>
<head>
<title>AJAX CHAT Administration System</title>
<script type="text/javascript"  src="http://code.jquery.com/jquery.min.js"></script>

<style> 

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

body {
font-family:Arial,Helvetica,sans-serif;

background:#000000;
}

#menucolumn{
background:#a9a4a4;
position:absolute;
border:2px solid;
border-radius:25px;
left:5px;
top:9%;
width:200px;
z-index:100;
height:650px;
}

p.Title1 {
position:relative;
font-size:200%;
}

p.Title2 {
position:relative;
font-size:80%;
top:-30px;
}

p.Navigation {
position:relative;
font-size:150%;
top:-10px;
font-weight:600;
}

p.Menu1 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.Menu2 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.Menu3 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.Menu4 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.Menu5 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.Menu6 {
position:relative;
font-size:100%;
left:5%;
top:10px;
font-weight:600;
}

p.credits {
position:relative;
font-size:50%;
left:5%;
top:10px;
}

.content {
	position: relative;
	padding-bottom: 40.25%;
	padding-top: 25px;
	height: 0;
    z-index:0;
}

.content iframe {
	position: absolute;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
	top: 0;
	left: 225px;
	width: 75%;
	height: 800px;
    z-index:1;
}

</style>

<script type="text/javascript">
$(document).ready(function(e) {

    $(".confirm").on("click", function(event){
            var ConfirmLabel;
            if(isset($(this).attr("confirmLabel"))){
                ConfirmLabel = $(this).attr("confirmLabel");
            }else{
                ConfirmLabel= "Are You sure?";
            }
            if(confirm(ConfirmLabel)){
               return true;
            } else {
                return false;
			}
	});
});

function isset() {
    var a = arguments,
    l = a.length,
    i = 0,
    undef;
    /////////////
    if (l === 0) {
        throw new Error('Empty isset');
    }
    /////////////
    while (i !== l) {
        if (a[i] === undef || a[i] === null) {
            return false;
        }
        i++;
    }
    return true;
}
</script>

</head>
<body>

             <div class="content">
<div id="menucolumn">
<center><p class="Title1" <h1><strong>AJAX CHAT</strong></h1></p>
<p class="Title2" <h1><strong>ADMINISTRATON SYSTEM</strong></h1></p>
<hr>
<p class="Navigation"<strong>NAVIGATION</strong></p></center>


<p class="Menu1"<strong><a title="Welcome Page - Main Dashbord" href="./dashboard.php" target="dashboard">Dashboard</a></strong></p>

<p class="Menu2"<strong><a title="Manage your chat members information" href="./sources/users/dashboard.php" target="dashboard">User Management</a></strong></p>

<p class="Menu3"<strong><a title="Add, edit, or delete a channel" href="./sources/channels/dashboard.php" target="dashboard">Channel Management</a></strong></p>

<p class="Menu4"<strong><a title="Register a new user" href="./sources/register/dashboard.php" target="dashboard">Register New Users</a></strong></p>

<p class="Menu5"<strong><a title="View and Manage Banned Users" href="./sources/banned/dashboard.php" target="dashboard">Banned Users List</a></strong></p>

<p class="Menu6"<strong><a href="./login.php" target="dashboard" class="confirm" confirmLabel="    If already logged in, Logging out will end your session. Ok to logout?    ">Logout</a></strong></p><br/><br/>

<hr>
<p class="credits"<strong><center>AJAX Chat Admin Script Version.1-b1<hr/><a href="http://frug.github.io/AJAX-Chat/" target="_blank">Ajax Chat</a> by <a href="http://blueimp.net" target="_blank">Blueimp</a><br/>Admin Script by <a href="http://clubsyn-x-treme.com" target="_blank">-SyN-</a><br/>Copywrite: 11/02/13<br/> All rights Reserved!</center></strong></p>
</div>

                <iframe name="dashboard"  src="./login.php" frameborder="0" scrolling="no"></iframe>
</div>
</body>
</html>

