<? ob_start(); ?>
<style>

body {
font-family:Arial,Helvetica,sans-serif;
}

div#wrapper{
position:relative;
margin-top:50px;
width:100%;
}


.news {
	position: relative;
}

.news iframe {
	position: relative;
    background:#a9a4a4;
	width: 100%;
	height: 368px;
}

</style>

<?php 

session_start();

$now = time();

if(!$_SESSION['adminNAME']){
  echo "<center><h1>Please Login First!<br/>Redirecting you to the login dashboard...</h1></center>";
header("refresh:2;url=./login.php");
session_destroy();

}else if($now > $_SESSION['expire'])
    {
        session_destroy();
        echo "<center><h1>Your session has expired<br/>Redirecting you to the login dashboard...</h1></center>"; 
        header("refresh:5;url=./login.php");

    }else{





echo "<div id=wrapper align=center>";
echo "<hr>";
echo "<h1>Welcome to your Dashboard!</h1>";
echo "<hr>";
echo "<table border=1 align=center style=border-spacing:1em; width=100%>";
echo "<tr><td>";
echo "<div class=news><iframe src=http://clubsyn-x-treme.com/syns_mods/index.html frameborder=0></iframe>";
echo "</td></tr></table><br/>";
echo "<table border=1 align=center style=border-spacing:1em; width=30%>";
echo "<th>AJAX CHAT Database Backup</th>";
echo "<tr><td><br/>";
echo "<center><form method=link action=./backup.php>";
echo "<input type=submit value=Create&nbsp;Backup>";
echo "</form></center>";
echo "</td></tr></table></div>";
echo "</div>";

}
?>
<? ob_flush(); ?>