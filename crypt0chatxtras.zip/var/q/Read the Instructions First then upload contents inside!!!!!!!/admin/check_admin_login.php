<? ob_start(); ?>
<?php

session_start();

require('../lib/config.php');

///////////////////////////////////////////////////////
//Connect to the chats Mysql Database
///////////////////////////////////////////////////////

mysql_connect($config['dbConnection']['host'],$config['dbConnection']['user'],$config['dbConnection']['pass']);
mysql_select_db($config['dbConnection']['name']);

///////////////////////////////////////////////////////
//Gets longin info and sets variables
///////////////////////////////////////////////////////

$name = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['adminNAME']))));
$pass = mysql_real_escape_string(htmlentities(strip_tags(trim($_POST['adminPASS']))));
$role = "AJAX_CHAT_ADMIN";

$sql = "SELECT * FROM ajax_chat_registered_members WHERE NAME='$name' AND PASS='$pass' AND ROLE='$role'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);

////////////////////////////////////////////////////////////
//Check to see if the variables matches a row of users info
////////////////////////////////////////////////////////////

if($count==1){
$_SESSION['adminNAME'] = $name;
$_SESSION['adminPASS'] = $pass;
$_SESSION['start'] = time(); 
$_SESSION['expire'] = $_SESSION['start'] + (20 * 40);
header("location:./dashboard.php");
}else{
header("location:./login_failed.php");
}

?>
<? ob_flush(); ?>