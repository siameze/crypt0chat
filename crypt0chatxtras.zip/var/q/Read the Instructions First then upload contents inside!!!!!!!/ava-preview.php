<title>Avatar Upload</title>


<script>
function goBack()
  {
  window.history.back()
  }
</script>

<style> 

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

body {
font-family:Arial,Helvetica,sans-serif;

background:#000000;
}

#AvaUPLOAD{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:auto;
}

</style>

<?php
$allowedExts = array("png");
$extension = end(explode(".", $_FILES["file"]["name"]));
if (($_FILES["file"]["type"] == "image/png")
&& ($_FILES["file"]["size"] < 200000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    }
  else
    {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "img/avatars/" . $_FILES["file"]["name"]);

echo "<div id=AvaUPLOAD align=center><br/><hr>";
echo "<h1>Upload was Successful!</h1>";
echo "<hr><br/>";

echo "<table border=2><tr><td>";
      echo "<img src=./img/avatars/".$_GET['user'].".png /></td></tr></table>";
      echo "<br/>Here is your new avatar!";
echo "<br/><br/><input type='button' value='Close this window' onclick='self.close()'><br/><br/></div>";
      }
    }
else
  {
  echo "<center>The file must be both .png and under 250kb in size!<br><br>";    
  echo "<input type='button' value='Go Back and Try Again' onclick='goBack()'></center>";
  }
?>