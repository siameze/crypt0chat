
<title>Avatar Upload</title>

<style> 

a{
text-decoration:none;
color: darkblue;
}

a:hover{
color: red;
}

body {
font-family:Arial,Helvetica,sans-serif;

background:#000000;
}

#AvaUPLOAD{
margin-left: auto;
margin-right: auto;
background:#a9a4a4;
border:2px solid;
border-radius:25px;
width:800px;
height:auto;
}

</style>


<?php
echo "<div id=AvaUPLOAD align=center><br/><hr>";
echo "<h1>Avatar Upload</h1>";
echo "<hr><br/>";

echo "<b>The Avatar must in .png format and the image name <b>MUST MATCH</b> your current chat username.</b><br/>";
echo "*<i>If your username is ".$_GET['user']." then the image must be ".$_GET['user'].".png</i>";
echo "<br/><br/><br/><br/>";
echo "<form action=ava-preview.php?user=".$_GET['user']." method=post enctype=multipart/form-data>";
echo "<label for=file>Choose your Avatar to Upload:</label>";
echo "<input type=file name=file id=file accept=image/*/>";
echo "<input type=submit name=submit value=Upload></form></div>";
?>
